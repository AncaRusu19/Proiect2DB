<?php
session_start(); // Pornim sesiunea

// Ștergem toate variabilele de sesiune
$_SESSION = [];

// Distrugem sesiunea
session_destroy();

// Ștergem cookie-ul
setcookie('user', '', time() - 3600, '/');

// Redirecționăm utilizatorul către pagina de login
header("Location: login.php");
exit;
?>
